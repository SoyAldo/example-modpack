#version 120
/* Aurora Fantasy - composite1.fsh
Render: Bloom, DoF and Motion blur

in2bubble - Based on MakeUp by KDXavier - GNU Lesser General Public License v3.0
*/

#define USE_BASIC_SH // Sets the use of a "basic" or "generic" shader for custom dimensions, instead of the default overworld shader. This can solve some rendering issues as the shader is closer to vanilla rendering.

#ifdef USE_BASIC_SH
    #define UNKNOWN_DIM
#endif
#define COMPOSITE1_SHADER

#include "/common/composite1_fragment.glsl"