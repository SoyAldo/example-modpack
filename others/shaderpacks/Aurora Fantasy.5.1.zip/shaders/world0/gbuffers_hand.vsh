#version 120
/* Aurora Fantasy - gbuffers_hand.vsh
Render: Hand opaque objects

in2bubble - Based on MakeUp by KDXavier - GNU Lesser General Public License v3.0
*/

#define GBUFFER_HAND

#include "/common/solid_blocks_vertex.glsl"
